#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<threads.h>
#include<string.h>
#include <complex.h>



#define A0  " 128  0   128"
#define A1  " 128  0   0  "
#define A2  " 0    255 0  "
#define A3  " 0    0   255"
#define A4  " 255  153 0  "
#define A5  " 192  192 192"
#define A6  " 0    51  102"
#define A7  " 255  255 0  "
#define A8  " 153  51  102"
#define A9  " 255  102 0  "
#define A10 " 255  103 94 "


const int max_iter = 51;
const float sqtol = 0.000001;
char colour_type[11][14] = {A0, A1, A2, A3, A4, A5, A6, A7, A8, A9,A10};
char gray_scale[52][4];
char *col_row;
char *gray_row;

typedef struct{

int val;
char pad[60];


}int_padded;

typedef struct{
mtx_t *mtx;
cnd_t *cnd;
int nmbr_thrds;
int sz;
int_padded *status;
}thrd_info_write_t;

typedef struct{
mtx_t *mtx;
cnd_t *cnd;
float step;
int sz;
int_padded *status;
int ib;
int tx;
int nmbr_thrds;
// Andhika Code Required variables
// Polynomial Degree
int d;
float complex * root_thrd_var;
}thrd_info_compute_t;



typedef struct {
float real;
float img;

}TYPE_ATTR;

typedef struct{
short int itr;
short int label;
}TYPE_CONV;

TYPE_ATTR ** attractors;
TYPE_CONV ** convergences; //1

//TYPE_ATTR** attractors   =   (TYPE_ATTR **)   malloc(1000  *  sizeof(TYPE_ATTR *));
//TYPE_CONV** convergences =   (TYPE_CONV **)   malloc( 1000 * sizeof(TYPE_CONV *));

void analytical_root (int, float complex *);
TYPE_CONV* root (TYPE_ATTR*, TYPE_CONV*,float complex*, int); //3
//void fwrite_pictures(TYPE_CONV *,int);
// Polynomial degree
//int d = 4;
float complex* roots;


int main_thrd_compute (void* args)
{

float start_real = -2.00000000000000;
float start_img  =  2.000000000000000;
const thrd_info_compute_t* thrd_info_compute = (thrd_info_compute_t*) args;
const int sz = thrd_info_compute->sz;
const float step = thrd_info_compute->step;
const int nmbr_thrds = thrd_info_compute->nmbr_thrds;
const int ib = thrd_info_compute->ib;
const int tx = thrd_info_compute->tx;
mtx_t *mtx = thrd_info_compute->mtx;
cnd_t *cnd = thrd_info_compute->cnd;
int_padded * status = thrd_info_compute->status;

//Andhika code variables here
TYPE_CONV * element;
int d =thrd_info_compute->d;
float complex *  root_thrd_var = thrd_info_compute->root_thrd_var;




for (int img_c =ib; img_c < sz ; img_c = img_c + nmbr_thrds )
{
  TYPE_ATTR * attractor = (TYPE_ATTR * )malloc(sz*sizeof(TYPE_ATTR));
  TYPE_CONV * convergence = (TYPE_CONV * )malloc(sz*sizeof(TYPE_CONV)); //5
  attractor[0].img = start_img - step * (float) img_c;
  //float temp = attractor[0].img; // we need this value as imaginary component is replaced by the iteration when root function is called . Temp just stores the value of the imaginary compnent to be used in later iterations while calling root function.
  //attractor[img_c][0].real = start_real ;
	 for (int real_c = 0; real_c < sz ; ++real_c   )
 {
 attractor [real_c].real = start_real + step * (float) real_c;
  if (real_c !=0 )
  {
 attractor[real_c].img = attractor[0].img;  //6
  }
  /*Andhika Code called here */
 //if (d==1)
 //{

//convergence[real_c].label = 0;
//convergence[real_c].itr = 1;
  //}
  //else {
	 // switch (d) // for degree 1 we dont want to call the compute function as the iteration is simply 1 and root label is 0.
	//  {
	//	case 1:

		//	 convergence[real_c].itr = 1;
	    //     convergence[real_c].label = 0;
		//	  break;


	 ///    default:
			element = root (&attractor[real_c],&convergence[real_c],root_thrd_var,d);  //7
			convergence[real_c].label = element->label;
			convergence[real_c].itr = element->itr;
		//	break;
	 // }
  //}








  }


mtx_lock(mtx);

convergences[img_c] = convergence;
status[tx].val = img_c + nmbr_thrds ;

/* We will print here which is not required in the assignment. Here Instead we will write the code which Andhika has written. We will call the functions here .*/
//printf ("%s%d %s %d %s %d %s %d %s %d %s %d %s %d %s"," !Thread: ",tx,"working : label  ", (int) attractors[img_c][0].real,", Iteration",(int) attractors[img_c][0].img, ", label ",(int) attractors[img_c][1].real, ", Iteration ", (int) attractors[img_c][1].img, ", Label ",(int)attractors[img_c][999].real, ", Iteration",(int)attractors[img_c][999].img, " \n");



mtx_unlock(mtx);
cnd_signal(cnd);

//thrd_sleep(&(struct timespec){.tv_sec=0, .tv_nsec=1000}, NULL);


}




return 0;

}



int main_thrd_write (void* args) /*This function is used by only 1 thread to write to a file the the roots of the polynomial equation as well as the iterations*/

{

const thrd_info_write_t * thrd_info_write= (thrd_info_write_t *) (args);
mtx_t* mtx = thrd_info_write->mtx;
cnd_t* cnd = thrd_info_write->cnd;
const int sz = thrd_info_write->sz;
int_padded *status = thrd_info_write->status;
const int nmbr_thrds = thrd_info_write->nmbr_thrds;
for (int img_c =0, trail ; img_c < sz ;  )
{

for (mtx_lock(mtx);;)
{


trail = sz;

 //We will wait for the compute to process a line and then only write that line in the final file.
for ( int x = 0; x < nmbr_thrds ; ++x )
{
	if ( trail > status[x].val )
            trail = status[x].val;
}
            if ( trail <= img_c )
 	      { cnd_wait(cnd,mtx);}

	     else {
	      mtx_unlock(mtx);
              break;
              }

}




 for ( ; img_c < trail ;  ++ img_c) {



/* We will print here which is not required in the assignment. Here Instead we will write the
code which Chen has written. We will call the write functions here .*/
//for (int test = 0; test < sz ; test++ )
//{

//printf("%i ",(int) attractors[img_c][test].real );
//printf ("%s%d %s %d %s %d %s %d %s %d %s %d %s %d %s"," !Writing Thread: ",1,"working : label  ",(int) attractors[img_c][0].real,", Iteration ",(int)attractors[img_c][0].img, ", label ",(int)attractors[img_c][1].real, ", Iteration",(int)attractors[img_c][1].img, ", label ",(int)attractors[img_c][999].real, ", Iteration",(int)attractors[img_c][999].img, " \n");
 //fwrite_pictures(convergences[img_c],sz); //8




FILE *file = fopen("newton_attractors_x.ppm","a");
if (file ==NULL){
    //printf("error opening file.\n");
    return -1;
}

FILE *file1 = fopen("newton_convergence_x.ppm","a");
if (file1 ==NULL){
	   // printf("error opening file.\n");
	  return 0;
	    // │}
}

for (int ix = 0;ix<sz;++ix){
//for (int iy = 0;iy<n;++iy){
//fprintf(file,"%i %i %i ",colour_type[convergence[ix].label][0],colour_type[convergence[ix].label][1],colour_type[convergence[ix].label ][2]);
strcpy(&col_row[ix*13], colour_type[convergences[img_c][ix].label]);
strcpy(&gray_row[ix*3],gray_scale[(convergences[img_c][ix].itr)]);

//fprintf(file1,"%i ",convergence[ix].itr);

}
//fprintf(file,"\n");
//}
fwrite(col_row,sizeof(char),sz*13,file);
fwrite(gray_row,sizeof(char),sz*3,file1);
//fprintf(file, "\n");
fwrite("\n", sizeof(char), 1, file);
fwrite("\n", sizeof(char), 1, file1);
//fprintf(file1, "\n");
fclose(file);
fclose(file1);








/*if (img_c == 0)






{

for (int test =0 ; test < sz ; ++test)
{
printf("%i  ", (int)attractors [img_c][test].img);
}
}*/
 free(attractors[img_c]); /*Now no need for the line which is already written in the file*/
 free(convergences[img_c]); //9
//}
//printf("%s", "\n");

}

}
return 0;


}


int main(int argc, char * argv[])
{


int size ;
int nmbr_thrds;
int d;

for (int ix = 1; ix < argc; ++ix)
	{
		if (argv[ix][1] == 't')
			nmbr_thrds = atoi(argv[ix]+2);
		else if (argv[ix][1] == 'l')
			size = atoi(argv[ix]+2);
		else
			d = atoi(argv[ix]);
	}



//float multiple1= ((float)1/(float)d); // A
//float multiple2 =(1 - multiple1); // B

col_row = (char*) malloc(size*sizeof(char)*14);
gray_row= (char*) malloc(size*sizeof(char)*4);
	for (int ix = 0; ix < 52; ++ix)
		sprintf(gray_scale[ix], "%2i ", ix);

//printf("%s %lf","The multiple 1 is", multiple1);
//printf("%s %lf","The multiple 2 is", multiple2);
//printf("%i %i %i\n",thread_n, line_n, size_n);
////from -2 ,2 two-dimensional array discrete with line_n points;
///


// Analytical root array (d+1 to accomodate root for divergence)
// Heap
//float complex *roots = (float complex*) malloc ((d+2) * sizeof(float complex));
// Stack

//int d = 5;
roots= (float complex *) malloc ((d+1)*sizeof(float complex));
float complex extra_root = 0.00000 + 0.00000 * I;
roots[d] = extra_root;



analytical_root(d, roots);


 //int nmbr_thrds = 1;
 // printf("%s", argv[2]);

thrd_t thrds[nmbr_thrds];
float step = ((float)4/(float) size);
//TYPE_ATTR output.real = -2.00000000000000;
//float sum;
//
//const int size = 1000;
 attractors =   (TYPE_ATTR **)   malloc(size  *   sizeof(TYPE_ATTR *));
 convergences = (TYPE_CONV **)   malloc(size   * sizeof(TYPE_CONV *)); //2
 thrd_t thrds_compute [nmbr_thrds];
 thrd_info_compute_t thrd_info_compute[nmbr_thrds];
 thrd_t thrd_write ;
 thrd_info_write_t thrd_info_write;

 mtx_t mtx;
 mtx_init(&mtx, mtx_plain);
 cnd_t cnd;
 cnd_init(&cnd);
 int_padded status[nmbr_thrds];


// Chen Code written here for making a file for the first time and initializing it .

FILE *file = fopen("newton_attractors_x.ppm","w");
if (file ==NULL){
    //printf("error opening file.\n");
    return -1;
}
//int colour_type[10][3]= {{128,0,128},{128,0,0},{0,255,0},{0,0,255},{255,153,0},{192,192,192},{0,51,102},{255,255,0},{153,51,102},{255,102,0}};

 char init_colour_file2[1][18];
 //char init_colour_file3[1][4];
 char init_colour_file1[3] = {'P', '3', '\n'};
 sprintf(init_colour_file2[0],"%i %i%s%i%i%i%s",size,size,"\n",2,5,5,"\n");
 //sprintf(init_colour_file3[0],"%i%i%i%s",2,5,5,"\n" );

fwrite (init_colour_file1,sizeof(char),3,file);
fwrite (init_colour_file2[0],sizeof(char),18,file);
//fwrite (init_colour_file3[0],sizeof(char),4,file);
//fprintf(file,"P3\n");
//fprintf(file,"%i %i\n",size,size);
//fprintf(file,"255\n");




fclose(file);




FILE *file1 = fopen("newton_convergence_x.ppm","w");
if (file1 ==NULL){
   // printf("error opening file.\n");
    return -1;
}

char init_gray_file2[1][17];
 //char init_colour_file3[1][4];
 char init_gray_file1[3] = {'P', '2', '\n'};
 sprintf(init_gray_file2[0],"%i %i%s%i%i%s",size,size,"\n",5,0,"\n");
 //sprintf(init_colour_file3[0],"%i%i%i%s",2,5,5,"\n" );

fwrite (init_gray_file1,sizeof(char),3,file);
fwrite (init_gray_file2[0],sizeof(char),17,file);


//fprintf(file1,"P2\n");
//fprintf(file1,"%i %i\n",size,size);
//fprintf(file1,"50\n");
fclose(file1);

for (int i=0; i < nmbr_thrds; ++i)
{

	thrd_info_compute[i].ib = i;
	thrd_info_compute[i].status = status;
	status[i].val=-1;
	thrd_info_compute[i].nmbr_thrds=(nmbr_thrds) ;
	thrd_info_compute[i].mtx= &mtx;
	thrd_info_compute[i].cnd = &cnd;
	thrd_info_compute[i].tx= i;
        thrd_info_compute[i].step = step;
        thrd_info_compute[i].sz = size;
   // Andhika Code related variables
    thrd_info_compute[i].d =d;
    thrd_info_compute[i].root_thrd_var=roots;

       int r = thrd_create(thrds_compute+i,main_thrd_compute, (void *) (thrd_info_compute+i));

//printf("%s","Hello");

     if ( r != thrd_success ) {
      fprintf(stderr, "failed to create thread\n");
      exit(1);
     }



   thrd_detach(thrds_compute[i]);
//printf("%s%d","Hello", i);
}
{

   thrd_info_write.mtx = &mtx;
   thrd_info_write.cnd = &cnd;
   thrd_info_write.nmbr_thrds=(nmbr_thrds);
   thrd_info_write.sz = size;
   thrd_info_write.status = status;
    int r = thrd_create(&thrd_write, main_thrd_write, (void*) (&thrd_info_write));
        if ( r != thrd_success ) {
		      //fprintf(stderr, "failed to create thread\n");
		            exit(1); }


//printf("%s%d","Hello");
}


 {
	     int r;
	     thrd_join(thrd_write, &r);

 }
free (attractors);
free (convergences);
mtx_destroy(&mtx);
cnd_destroy(&cnd);
free (col_row);
free(gray_row);
      return 0;

}




// ANALYTICAL_ROOT: this function receives order of the function d and return roots (xa + i ya)
void analytical_root (int d, float complex *roots)
{
// Variable declaration
float complex za_polar, za_euler;

for (int k = 0; k < d; ++k)
	{
	//za_polar = cos (2*k*PI/d) + (sin (2*k*PI/d))*I;
	za_euler = cexpf(2* I * M_PI * k / d);
	roots[k] = za_euler;
	//printf("analytical root z[%d] = %f +%fi\n\n", k+1, crealf(roots[k]), cimagf(roots[k]));
	}
}




// ROOT: this function receives an initial complex value (x + i y), absolute complex root (xa + i ya), order of the function (d),
// and return the root that the initial complex value converges to.
TYPE_CONV* root (TYPE_ATTR *input, TYPE_CONV * output,/*float complex zn*/ float complex *roots, int d) //4
{


//printf("%s %lf %s %lf", "Real Part:", input->real," Imaginary Part : ",input->img);
//int max_iter = 51; // maybe make this global(?)
int iter = 0;
//float sqtol = 0.000001; // maybe make this global(?)
int root_index; // to get the index of the root (or "label") which the initial complex number converges to
int brake = 0;
//const float multiple3 = (float)1/((float)((input->real*input->real)+(input->img*input->img)));// The is inverse of the difference of real number and imaginary coefficient.

float complex zn = input->real + input->img * I;
float complex zc = input->real - input->img * I; //(conjugate of Zn)
  float norm_sq = zn * zc;
  //float multiple3 = (1)/norm_sq;
  //printf("%lf", multiple3);


for (int i = 0; i < max_iter; ++i)
	{
	//iter += 1;
	//float complex z_pow = 1.0; // This one is for power calculation using for loop, not needed
	//float norm_sq = zn * conj(zn);

	// Check if zn too close to origin point or its real or imaginary component exceeds 1.0e+10
	if (norm_sq < sqtol || fabs(crealf(zn)) > 1.0e+10 || fabs(cimagf(zn)) > 1.0e+10)
		{
		root_index = d ;
		//printf ("Number of iterations: %d\n",  iter);
		break;
		}

	// Check to which root the initial complex number converges to, this for loop is gonna iterate
	// through the roots array
	for (int k = 0; k < d; ++k)
		{
		if ( ((crealf(roots[k] - zn))*(crealf(roots[k] - zn)) + (cimagf(roots[k] - zn))*(cimagf(roots[k] -zn)) ) < sqtol)
			{
			root_index = k;
			//printf ("No. of iteration: %d\n", iter);
			//printf ("zn converges to root z =  %f + %fi\n", crealf(roots[root_index]), cimagf(roots[root_index]));
			//printf ("zn = %f + %fi\n", crealf(zn), cimagf(zn));
			brake += 1;
			break;
			}
		}

	 if (brake == 1)
		          {
			break;
	}

/*
	// For loop to calculate the power of zn (stops at d-1 which is equal to the power of the
	// denumerator)
	for (int i = 0; i < d-1; ++i)
		{
		z_pow = z_pow * zn;
		}

	zn = zn - ((z_pow * zn) - 1)/(d * (z_pow));
*/

	// Newton's method for each degree (d)
	switch (d)
		{
		case 1:
			zn = 1;
			break;
		case 2:

			//zn = (zn*zn + 1) / (2*zn);
                         zn = (zn) / 2 + 1 / (2*zn);


			break;
		case 3:
			//zn = (2*zn*zn*zn + 1) / (3 * zn*zn);
                        zn = (2*zn) / 3 + 1 / (3 * zn*zn);
						//zn= (multiple2)*zn + multiple1*multiple3*zc*zc;
			break;
		case 4:
			//zn = (3*zn*zn*zn*zn + 1) / (4 * zn*zn*zn);
			  //zn = (3*zn*zn*zn*zn + 1) / (4 * zn*zn*zn);  //This always works
                          //zn = (3/4 * zn) + 1 / (4 * zn*zn*zn); //why doesn't this work??
                        zn = (3*zn) / 4 + 1 / (4 * zn*zn*zn);   //This guy works as well
                       //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc;
                         break;
		case 5:
		 	 //zn = (4*zn*zn*zn*zn*zn + 1) / (5 * zn*zn*zn*zn);
                          zn = (4*zn) / 5 + 1 / (5 * zn*zn*zn*zn);
						  //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc;
                         break;

			break;
		case 6:
			//zn = (5*zn*zn*zn*zn*zn*zn + 1) / (6 * zn*zn*zn*zn*zn);
		         //zn = (5*zn*zn*zn*zn*zn*zn + 1) / (6 * zn*zn*zn*zn*zn);
                         zn = (5*zn) / 6 + 1 / (6 * zn*zn*zn*zn*zn);
						  //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc*zc;

                       break;
		case 7:
			//zn = (6*zn*zn*zn*zn*zn*zn*zn + 1) / (7 * zn*zn*zn*zn*zn*zn);
			//zn = (6*zn*zn*zn*zn*zn*zn*zn + 1) / (7 * zn*zn*zn*zn*zn*zn);
                        zn = (6*zn) / 7 + 1 / (7 * zn*zn*zn*zn*zn*zn);
                     //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc*zc*zc;

                        break;
		case 8:
			//zn = (7*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (8 * zn*zn*zn*zn*zn*zn*zn);
			  //zn = (7*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (8 * zn*zn*zn*zn*zn*zn*zn);
                       zn = (7*zn) / 8 + 1 / (8 * zn*zn*zn*zn*zn*zn*zn);
                 //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc*zc*zc*zc;

                        break;
		case 9:
			//zn = (8*zn*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (9 * zn*zn*zn*zn*zn*zn*zn*zn);

                          //zn = (8*zn*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (9 * zn*zn*zn*zn*zn*zn*zn*zn);
                         zn = (8*zn) / 9 + 1 / (9 * zn*zn*zn*zn*zn*zn*zn*zn);
                    //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc*zc*zc*zc*zc;

                        break;
		case 10:
		        //zn = (9*zn*zn*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (10 * zn*zn*zn*zn*zn*zn*zn*zn*zn);
                        zn = (9*zn) / 10 + 1 / (10 * zn*zn*zn*zn*zn*zn*zn*zn*zn);
                       //zn= (multiple2)*zn + multiple1*multiple3*zc*zc*zc*zc*zc*zc*zc*zc*zc;


                      //zn = (9*zn*zn*zn*zn*zn*zn*zn*zn*zn*zn + 1) / (10 * zn*zn*zn*zn*zn*zn*zn*zn*zn);
			break;
		}


	iter += 1;

	if (iter == max_iter)

  {
     root_index=d ;
  break;

  }



	}



output->label = /*0.00000 + (float)*/ root_index;
output->itr = /*0.00000+ (float)*/ iter;





//printf ("Index of the root: %lf\n", input->real/*root_index*/);
//printf ("zn = %f + %fi\n", crealf(zn), cimagf(zn));
//printf ("iteration: %lf\n", input->img /*iter*/);

//printf ("Index of the root: %d\n", root_index);
//printf ("zn = %f + %fi\n", crealf(zn), cimagf(zn));
//printf ("iteration: %d\n", iter);

//printf("%d %s %d %s",(int)input->real," ######## ", (int) input->img,"\n" );
return output;
}


//void fwrite_pictures(TYPE_CONV * convergence,int n){




//for (int test =0 ; test < 1000 ; ++test)
//{
//printf("%i  ", (int)attractor[test].img);
//}


///////////////////////////////////////fwrite with colour///////////////////////////////////



//}











